/* DINCĂ Alexandra-Cristina - 311CD */

ListNode* createNode (char elem);
List* createList (void);
StackNode* createStackNode (ListNode *position);
Stack* createStack (void);
QueueNode* createQueueNode (char *command);
Queue* createQueue (void);