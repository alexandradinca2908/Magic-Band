/* DINCĂ Alexandra-Cristina - 311CD */

void showCurrent (List *list, FILE *out);
void showAll (List *list, FILE *out);