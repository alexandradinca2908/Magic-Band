/* DINCĂ Alexandra-Cristina - 311CD */

void moveFinger(List *list, char *command);
void moveToChar (List *list, char *command, FILE *out);
void writeChar (List *list, char *command);
void insertChar (List *list, char *command, FILE *out);